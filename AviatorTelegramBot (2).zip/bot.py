import os
import logging
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

# ✅ Données entièrement remplies
TELEGRAM_TOKEN = "8123549153:AAFJdCrCOd4yQxGInUDnocTe2WbHPdhIXWc"
TELEGRAM_CHAT_ID = "7361668969"
AVIATOR_EMAIL = "Matgau89"
AVIATOR_PASSWORD = "Magalie_112b"
AVIATOR_URL = "https://www.ca-raceupcasino.com/en-CA?bar=modal"

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = (
        f"✅ Bot Aviator opérationnel !\n"
        f"👤 Email : {AVIATOR_EMAIL}\n"
        f"🔑 Mot de passe : {AVIATOR_PASSWORD}\n"
        f"🌐 URL : {AVIATOR_URL}\n"
        f"🗂️ Chat ID : {TELEGRAM_CHAT_ID}"
    )
    await context.bot.send_message(chat_id=update.effective_chat.id, text=message)

if __name__ == '__main__':
    application = ApplicationBuilder().token(TELEGRAM_TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.run_polling()
